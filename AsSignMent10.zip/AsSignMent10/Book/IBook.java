
package AsSignMent10.Book;

public interface IBook {
    void addBook();
boolean updateBookById();
void displayDetails();
double calculate();

}
